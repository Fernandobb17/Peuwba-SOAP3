package modelo;
import java.util.List;
import java.util.ArrayList;

public class Jornada {
    private int idJornada;
    private String tipo;  
    private String fecha;
    private Chofer idChofer;
    private List<Carrera> carreras;

    public Jornada(int idJornada, String tipo, String fecha, Chofer idChofer) {
        this.idJornada = idJornada;
        this.tipo = tipo;
        this.fecha = fecha;
        this.idChofer = idChofer;
        this.carreras = new ArrayList<>();
    }

    public int getIdJornada() {
        return idJornada;
    }

    public void setIdJornada(int idJornada) {
        this.idJornada = idJornada;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Chofer getIdChofer() {
        return idChofer;
    }

    public void setIdChofer(Chofer idChofer) {
        this.idChofer = idChofer;
    }

    public List<Carrera> getCarreras() {
        return carreras;
    }

    public void setCarreras(List<Carrera> carreras) {
        this.carreras = carreras;
    }

    @Override
    public String toString() {
        return "Jornada{" +
                "idJornada=" + idJornada +
                ", tipo='" + tipo + '\'' +
                ", fecha='" + fecha + '\'' +
                ", fecha='" + fecha + '\'' +
                ", carreras=" + carreras +
                ", chofer=" + idChofer +
                '}';
    }
}