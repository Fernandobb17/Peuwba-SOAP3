package modelo;
public class Carrera {
    private int idCarrera;
    private String origen;
    private String destino;
    private double valorCarrera;
    private String fechaHora;
    private Jornada idJornada;

    public Carrera(int idCarrera, String origen, String destino,
                   double valorCarrera, String fechaHora, Jornada idJornada) {
        this.idCarrera = idCarrera;
        this.origen = origen;
        this.destino = destino;
        this.valorCarrera = valorCarrera;
        this.fechaHora = fechaHora;
        this.idJornada = idJornada;
    }

    public int getIdCarrera() {
        return idCarrera;
    }

    public void setIdCarrera(int idCarrera) {
        this.idCarrera = idCarrera;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public double getValorCarrera() {
        return valorCarrera;
    }

    public void setValorCarrera(double valorCarrera) {
        this.valorCarrera = valorCarrera;
    }

    public String getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

    public Jornada getIdJornada() {
        return idJornada;
    }

    public void setIdJornada(Jornada idJornada) {
        this.idJornada = idJornada;
    }

    @Override
    public String toString() {
        return "Carrera{" +
                "idCarrera=" + idCarrera +
                ", origen='" + origen + '\'' +
                ", destino='" + destino + '\'' +
                ", valorCarrera=" + valorCarrera +
                ", fechaHora='" + fechaHora + '\'' +
                ", jornada='" + idJornada + '\'' +
                '}';
    }
}