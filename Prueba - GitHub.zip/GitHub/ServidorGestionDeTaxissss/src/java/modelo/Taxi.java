package modelo;
import java.util.List;
import java.util.ArrayList;

public class Taxi {
    private int idTaxi;
    private String placa;
    private String marca;
    private String modelo;
    private int anio;
    private Propietario idPropietario;
    private List<Chofer> choferes;    
    
    public Taxi(){}

    public Taxi(int idTaxi, String placa, String marca, String modelo, int anio, Propietario idPropietario) {
        this.idTaxi = idTaxi;
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
        this.idPropietario = idPropietario;
        this.choferes = new ArrayList<>();
    }
    public int getIdTaxi() {
        return idTaxi;
    }
    public void setIdTaxi(int idTaxi) {
        this.idTaxi = idTaxi;
    }
    public String getPlaca() {
        return placa;
    }
    public void setPlaca(String placa) {
        this.placa = placa;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public int getAnio() {
        return anio;
    }
    public void setAnio(int anio) {
        this.anio = anio;
    }

    public Propietario getIdPropietario() {
        return idPropietario;
    }

    public void setIdPropietario(Propietario idPropietario) {
        this.idPropietario = idPropietario;
    }

    public List<Chofer> getChoferes() {
        return choferes;
    }
    public void setChoferes(List<Chofer> choferes) {
        this.choferes = choferes;
    }
    
    @Override
    public String toString() {
        return "Taxi{" +
                "idTaxi=" + idTaxi +
                ", placa='" + placa + '\'' +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", anio=" + anio +
                ", choferes=" + choferes +
                '}';
    }
}
