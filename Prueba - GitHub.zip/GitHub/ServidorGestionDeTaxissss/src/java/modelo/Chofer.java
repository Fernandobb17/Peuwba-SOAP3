package modelo;
    
import java.util.List;
import java.util.ArrayList;

public class Chofer {
    private String cedula;
    private String nombres;
    private String apellidos;
    private String telefono;
    private String licencia;
    private Taxi idTaxi;
    
    private List<Jornada> jornadas;

    public Chofer(String cedula, String nombres, String apellidos,
                  String telefono, String licencia, Taxi idTaxi) {
        this.cedula = cedula;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.licencia = licencia;
        this.idTaxi =  idTaxi;
        this.jornadas = new ArrayList<>();
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getLicencia() {
        return licencia;
    }

    public void setLicencia(String licencia) {
        this.licencia = licencia;
    }

    public Taxi getIdTaxi() {
        return idTaxi;
    }

    public void setIdTaxi(Taxi idTaxi) {
        this.idTaxi = idTaxi;
    }

    public List<Jornada> getJornadas() {
        return jornadas;
    }

    public void setJornadas(List<Jornada> jornadas) {
        this.jornadas = jornadas;
    }

    

    @Override
    public String toString() {
        return "Chofer{" +
                "cedula='" + cedula + '\'' +
                ", nombres='" + nombres + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", telefono='" + telefono + '\'' +
                ", licencia='" + licencia + '\'' +
                ", jornadas='" + jornadas + '\'' +
                ", Taxi=" +  idTaxi +
                '}';
    }
}