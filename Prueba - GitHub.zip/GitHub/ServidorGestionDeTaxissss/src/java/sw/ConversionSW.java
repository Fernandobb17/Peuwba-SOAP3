package sw;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.util.*;
import modelo.*;

@WebService(serviceName = "ConversionSW")
public class ConversionSW {

    private static List<Propietario> propietarios = new ArrayList<>();
    private static List<Taxi> taxis = new ArrayList<>();
    private static List<Chofer> choferes = new ArrayList<>();
    private static List<Jornada> jornadas = new ArrayList<>();
    private static List<Carrera> carreras = new ArrayList<>();

    static {
        //Propietarios
        Propietario p1 = new Propietario ("0981503586", "Diego", "Bernal", "0107122095", 60.0, 40.0);
        Propietario p2 = new Propietario ("0998297373", "Diego", "Bernal", "0107122096", 50.0, 45.0);
        propietarios.add(p1);
        propietarios.add(p2);      

        //Taxis
        Taxi t1 = new Taxi(1, "G-1111", "Toyota",  "Corolla", 2020, p1);
        Taxi t2 = new Taxi(2, "G-2222", "Chevrolet","Aveo",   2019, p1);
        Taxi t3 = new Taxi(3, "G-3333", "Kia",     "Rio",     2016, p2);
        taxis.add(t1); taxis.add(t2); taxis.add(t3);

        p1.getTaxis().add(t1);
        p1.getTaxis().add(t2);
        p2.getTaxis().add(t3);

        //Choferes
        Chofer c1 = new Chofer("1712345678", "Luis",   "Pérez",   "0981111111", "B1", t1);
        Chofer c2 = new Chofer("1723456789", "Mario",  "Torres",  "0982222222", "B1", t1);
        Chofer c3 = new Chofer("1734567890", "Jorge",  "Vásquez", "0983333333", "B1", t2);
        Chofer c4 = new Chofer("1745678901", "Pedro",  "Mora",    "0984444444", "B1", t3);
        choferes.add(c1); choferes.add(c2); choferes.add(c3); choferes.add(c4);

        t1.getChoferes().add(c1);
        t1.getChoferes().add(c2);
        t2.getChoferes().add(c3);
        t3.getChoferes().add(c4);

        // ── Jornadas -
        Jornada j1 = new Jornada(1, "Día",   "2025-06-01", c1);
        Jornada j2 = new Jornada(2, "Noche", "2025-06-01", c1);
        Jornada j3 = new Jornada(3, "Día",   "2025-06-01", c2);
        Jornada j4 = new Jornada(4, "Día",   "2025-06-01", c3);
        Jornada j5 = new Jornada(5, "Noche", "2025-06-01", c4);
        jornadas.add(j1); jornadas.add(j2); jornadas.add(j3);
        jornadas.add(j4); jornadas.add(j5);

        c1.getJornadas().add(j1);
        c1.getJornadas().add(j2);
        c2.getJornadas().add(j3);
        c3.getJornadas().add(j4);
        c4.getJornadas().add(j5);

        // Carreras 
        // Jornada 1 — Luis, taxi t1, Día
        Carrera ca1 = new Carrera(1, "Norte",  "Sur",    3.50, "08:00", j1);
        Carrera ca2 = new Carrera(2, "Centro", "Norte",  4.00, "09:00", j1);
        Carrera ca3 = new Carrera(3, "Sur",    "Este",   5.00, "10:30", j1);

        
        Carrera ca4 = new Carrera(4, "Este",   "Oeste",  6.00, "21:00", j2);
        Carrera ca5 = new Carrera(5, "Norte",  "Centro", 3.00, "22:00", j2);
        
        
        Carrera ca6 = new Carrera(6, "Oeste",  "Sur",    4.50, "08:30", j3);
        Carrera ca7 = new Carrera(7, "Sur",    "Centro", 3.50, "10:00", j3);
        
        
        Carrera ca8 = new Carrera(8,  "Norte", "Este",   5.50, "07:00", j4);
        Carrera ca9 = new Carrera(9,  "Este",  "Centro", 4.00, "09:30", j4);
        Carrera ca10= new Carrera(10, "Sur",   "Norte",  3.00, "11:00", j4);
        
        
        Carrera ca11= new Carrera(11, "Centro","Oeste",  7.00, "20:00", j5);
        Carrera ca12= new Carrera(12, "Norte", "Sur",    5.50, "22:30", j5);

        carreras.addAll(Arrays.asList(ca1,ca2,ca3,ca4,ca5,ca6,ca7,ca8,ca9,ca10,ca11,ca12));

        j1.getCarreras().addAll(Arrays.asList(ca1, ca2, ca3));
        j2.getCarreras().addAll(Arrays.asList(ca4, ca5));
        j3.getCarreras().addAll(Arrays.asList(ca6, ca7));
        j4.getCarreras().addAll(Arrays.asList(ca8, ca9, ca10));
        j5.getCarreras().addAll(Arrays.asList(ca11, ca12));
    }

    /*las carreras de un taxi y devuelver el total recaudado. */
    private double totalRecaudadoPorTaxi(Taxi taxi) {
        double total = 0;
        for (Chofer ch : taxi.getChoferes()) {
            for (Jornada j : ch.getJornadas()) {
                // Solo carreras cuyo chofer pertenece a este taxi
                if (j.getIdChofer().getIdTaxi().getIdTaxi() == taxi.getIdTaxi()) {
                    for (Carrera ca : j.getCarreras()) {
                        total += ca.getValorCarrera();
                    }
                }
            }
        }
        return total;
    }

    /** Contar el total de carreras de un taxi. */
    private int totalCarrerasPorTaxi(Taxi taxi) {
        int total = 0;
        for (Chofer ch : taxi.getChoferes()) {
            for (Jornada j : ch.getJornadas()) {
                if (j.getIdChofer().getIdTaxi().getIdTaxi() == taxi.getIdTaxi()) {
                    total += j.getCarreras().size();
                }
            }
        }
        return total;
    }

    // 1. Ganancia total del propietario
    // **************************************************************
    @WebMethod(operationName = "a1-obtenerGananciaPropietario")
    public String obtenerGananciaPropietario(
            @WebParam(name = "cedula") String cedula) {

        Propietario propietario = null;
        for (Propietario p : propietarios) {
            if (p.getCedula().equals(cedula)) { propietario = p; break; }
        }
        if (propietario == null)
            return "ERROR: No se encontró un propietario con cédula: " + cedula;

        double totalRecaudado = 0;
        double totalGanancia  = 0;

        StringBuilder sb = new StringBuilder();
        sb.append("=== GANANCIA DEL PROPIETARIO ===\n");
        sb.append("Propietario : ").append(propietario.getNombres())
          .append(" ").append(propietario.getApellidos()).append("\n");
        sb.append("Cédula      : ").append(propietario.getCedula()).append("\n");
        sb.append("% Propietario: ").append(propietario.getPorcentajePropietario()).append("%\n\n");

        for (Taxi taxi : propietario.getTaxis()) {
            double recaudadoTaxi = totalRecaudadoPorTaxi(taxi);
            double gananciaTaxi  = recaudadoTaxi * propietario.getPorcentajePropietario() / 100.0;
            totalRecaudado += recaudadoTaxi;
            totalGanancia  += gananciaTaxi;

            sb.append("  Taxi: ").append(taxi.getPlaca())
              .append(" (").append(taxi.getMarca()).append(" ").append(taxi.getModelo()).append(")\n");
            sb.append("    Recaudado : $").append(String.format("%.2f", recaudadoTaxi)).append("\n");
            sb.append("    Ganancia  : $").append(String.format("%.2f", gananciaTaxi)).append("\n\n");
        }

        sb.append("─────────────────────────────────\n");
        sb.append("Total recaudado (todos los taxis) : $").append(String.format("%.2f", totalRecaudado)).append("\n");
        sb.append("GANANCIA TOTAL DEL PROPIETARIO   : $").append(String.format("%.2f", totalGanancia)).append("\n");
        return sb.toString();
    }

    // 2. Ganancia de un chofer
    // **************************************************************
    @WebMethod(operationName = "a2-obtenerGananciaChofer")
    public String obtenerGananciaChofer(
            @WebParam(name = "cedulaChofer") String cedulaChofer) {

        Chofer chofer = null;
        for (Chofer ch : choferes) {
            if (ch.getCedula().equals(cedulaChofer)) { chofer = ch; break; }
        } if (chofer == null)
            return "ERROR: No se encontró un chofer con cédula: " + cedulaChofer;

        Propietario propietario = chofer.getIdTaxi().getIdPropietario();
        double totalRecaudado   = 0;
        int totalCarreras    = 0;

        StringBuilder sb = new StringBuilder();
        sb.append("=== GANANCIA DEL CHOFER ===\n");
        sb.append("Chofer    : ").append(chofer.getNombres())
          .append(" ").append(chofer.getApellidos()).append("\n");
        sb.append("Cédula    : ").append(chofer.getCedula()).append("\n");
        sb.append("Taxi      : ").append(chofer.getIdTaxi().getPlaca()).append("\n");
        sb.append("% Chofer  : ").append(propietario.getPorcentajeChofer()).append("%\n\n");

        for (Jornada j : chofer.getJornadas()) {
            double totalJornada = 0;
            for (Carrera ca : j.getCarreras()) {
                totalJornada += ca.getValorCarrera();
                totalCarreras++;
            }
            double gananciaJornada = totalJornada * propietario.getPorcentajeChofer() / 100.0;
            totalRecaudado += totalJornada;

            sb.append("  Jornada ").append(j.getIdJornada())
              .append(" (").append(j.getTipo()).append(" - ").append(j.getFecha()).append(")\n");
            sb.append("    Carreras  : ").append(j.getCarreras().size()).append("\n");
            sb.append("    Recaudado : $").append(String.format("%.2f", totalJornada)).append("\n");
            sb.append("    Ganancia  : $").append(String.format("%.2f", gananciaJornada)).append("\n\n");
        }
        double gananciaTotal = totalRecaudado * propietario.getPorcentajeChofer() / 100.0;
        sb.append("─────────────────────────────────\n");
        sb.append("Total carreras realizadas : ").append(totalCarreras).append("\n");
        sb.append("Total recaudado           : $").append(String.format("%.2f", totalRecaudado)).append("\n");
        sb.append("GANANCIA TOTAL DEL CHOFER : $").append(String.format("%.2f", gananciaTotal)).append("\n");
        return sb.toString();
    }

    // 3. Total de carreras por taxi
    // **************************************************************
    @WebMethod(operationName = "a3-obtenerTotalCarrerasPorTaxi")
    public String obtenerTotalCarrerasPorTaxi(
            @WebParam(name = "placa") String placa) {

        Taxi taxi = null;
        for (Taxi t : taxis) {
            if (t.getPlaca().equalsIgnoreCase(placa)) { taxi = t; break; }
        }
        if (taxi == null)
            return "ERROR: No se encontró un taxi con placa: " + placa;

        int total = totalCarrerasPorTaxi(taxi);

        StringBuilder sb = new StringBuilder();
        sb.append("=== CARRERAS POR TAXI ===\n");
        sb.append("Taxi  : ").append(taxi.getPlaca())
          .append(" | ").append(taxi.getMarca()).append(" ").append(taxi.getModelo())
          .append(" (").append(taxi.getAnio()).append(")\n\n");

        for (Chofer ch : taxi.getChoferes()) {
            sb.append("  Chofer: ").append(ch.getNombres()).append(" ").append(ch.getApellidos()).append("\n");
            for (Jornada j : ch.getJornadas()) {
                if (j.getIdChofer().getIdTaxi().getIdTaxi() == taxi.getIdTaxi()) {
                    sb.append("    Jornada ").append(j.getIdJornada())
                      .append(" (").append(j.getTipo()).append("): ")
                      .append(j.getCarreras().size()).append(" carrera(s)\n");
                }
            }
        }

        sb.append("─────────────────────────────────\n");
        sb.append("TOTAL DE CARRERAS: ").append(total).append("\n");
        return sb.toString();
    }

    // 4. Taxi más rentable de un propietario
    // **************************************************************
    @WebMethod(operationName = "a4obtenerTaxiMasRentable")
    public String obtenerTaxiMasRentable(
            @WebParam(name = "cedulaPropietario") String cedulaPropietario) {

        Propietario propietario = null;
        for (Propietario p : propietarios) {
            if (p.getCedula().equals(cedulaPropietario)) { propietario = p; break; }
        }
        if (propietario == null)
            return "ERROR: No se encontró un propietario con cédula: " + cedulaPropietario;

        if (propietario.getTaxis().isEmpty())
            return "El propietario no tiene taxis registrados.";

        Taxi   mejorTaxi  = null;
        double mejorMonto = -1;

        StringBuilder detalle = new StringBuilder();
        detalle.append("=== TAXI MÁS RENTABLE ===\n");
        detalle.append("Propietario: ").append(propietario.getNombres())
               .append(" ").append(propietario.getApellidos()).append("\n\n");

        for (Taxi t : propietario.getTaxis()) {
            double recaudado = totalRecaudadoPorTaxi(t);
            detalle.append("  ").append(t.getPlaca())
                   .append(" → $").append(String.format("%.2f", recaudado)).append("\n");
            if (recaudado > mejorMonto) {
                mejorMonto = recaudado;
                mejorTaxi  = t;
            }
        }

        detalle.append("\n─────────────────────────────────\n");
        detalle.append("TAXI MÁS RENTABLE\n");
        detalle.append("  Placa  : ").append(mejorTaxi.getPlaca()).append("\n");
        detalle.append("  Marca  : ").append(mejorTaxi.getMarca())
               .append(" ").append(mejorTaxi.getModelo()).append("\n");
        detalle.append("  Año    : ").append(mejorTaxi.getAnio()).append("\n");
        detalle.append("  Total recaudado: $").append(String.format("%.2f", mejorMonto)).append("\n");
        return detalle.toString();
    }

    // 5. Chofer con mayor número de carreras
    // **************************************************************
    @WebMethod(operationName = "a5obtenerMejorChofer")
    public String obtenerMejorChofer(
            @WebParam(name = "cedulaPropietario") String cedulaPropietario) {

        Propietario propietario = null;
        for (Propietario p : propietarios) {
            if (p.getCedula().equals(cedulaPropietario)) { propietario = p; break; }
        }
        if (propietario == null)
            return "ERROR: No se encontró un propietario con cédula: " + cedulaPropietario;

        Chofer mejorChofer   = null;
        int    mejorCantidad = -1;

        StringBuilder detalle = new StringBuilder();
        detalle.append("=== CHOFER CON MÁS CARRERAS ===\n");
        detalle.append("Propietario: ").append(propietario.getNombres())
               .append(" ").append(propietario.getApellidos()).append("\n\n");

        for (Taxi t : propietario.getTaxis()) {
            detalle.append("  Taxi: ").append(t.getPlaca()).append("\n");
            for (Chofer ch : t.getChoferes()) {
                int cant = 0;
                for (Jornada j : ch.getJornadas()) {
                    if (j.getIdChofer().getIdTaxi().getIdTaxi() == t.getIdTaxi()) {
                        cant += j.getCarreras().size();
                    }
                }
                detalle.append("    ").append(ch.getNombres()).append(" ")
                       .append(ch.getApellidos()).append(" → ").append(cant).append(" carrera(s)\n");
                if (cant > mejorCantidad) {
                    mejorCantidad = cant;
                    mejorChofer   = ch;
                }
            }
        }

        if (mejorChofer == null)
            return "No se encontraron choferes registrados para este propietario.";

        detalle.append("\n─────────────────────────────────\n");
        detalle.append("MEJOR CHOFER\n");
        detalle.append("  Nombre  : ").append(mejorChofer.getNombres())
               .append(" ").append(mejorChofer.getApellidos()).append("\n");
        detalle.append("  Cédula  : ").append(mejorChofer.getCedula()).append("\n");
        detalle.append("  Taxi    : ").append(mejorChofer.getIdTaxi().getPlaca()).append("\n");
        detalle.append("  Carreras: ").append(mejorCantidad).append("\n");
        return detalle.toString();
    }
    
    
    // 6. Ingresos de un taxi por tipo de jornada 
    // **************************************************************
    @WebMethod(operationName = "a6obtenerIngresosPorJornada")
    public String obtenerIngresosPorJornada(
            @WebParam(name = "placa")   String placa,
            @WebParam(name = "jornada") String jornada) {

        Taxi taxi = null;
        for (Taxi t : taxis) {
            if (t.getPlaca().equalsIgnoreCase(placa)) { taxi = t; break; }
        }
        if (taxi == null)
            return "ERROR: No se encontró un taxi con placa: " + placa;

        double totalIngreso  = 0;
        int    totalCarreras = 0;

        StringBuilder sb = new StringBuilder();
        sb.append("=== INGRESOS POR JORNADA ===\n");
        sb.append("Taxi    : ").append(taxi.getPlaca())
          .append(" (").append(taxi.getMarca()).append(" ").append(taxi.getModelo()).append(")\n");
        sb.append("Jornada : ").append(jornada).append("\n\n");

        for (Chofer ch : taxi.getChoferes()) {
            for (Jornada j : ch.getJornadas()) {
                if (j.getIdChofer().getIdTaxi().getIdTaxi() == taxi.getIdTaxi()
                        && j.getTipo().equalsIgnoreCase(jornada)) {

                    double subtotal = 0;
                    for (Carrera ca : j.getCarreras()) subtotal += ca.getValorCarrera();
                    totalIngreso  += subtotal;
                    totalCarreras += j.getCarreras().size();

                    sb.append("  Jornada ").append(j.getIdJornada())
                      .append(" | Fecha: ").append(j.getFecha())
                      .append(" | Chofer: ").append(ch.getNombres()).append(" ").append(ch.getApellidos()).append("\n");
                    for (Carrera ca : j.getCarreras()) {
                        sb.append("    • ").append(ca.getOrigen()).append(" → ").append(ca.getDestino())
                          .append("  $").append(String.format("%.2f", ca.getValorCarrera()))
                          .append("  (").append(ca.getFechaHora()).append(")\n");
                    }
                    sb.append("    Subtotal jornada: $").append(String.format("%.2f", subtotal)).append("\n\n");
                }
            }
        }

        if (totalCarreras == 0) {
            return "No se encontraron jornadas de tipo '" + jornada + "' para el taxi " + placa;
        }

        sb.append("─────────────────────────────────\n");
        sb.append("Total carreras en jornada ").append(jornada).append(" : ").append(totalCarreras).append("\n");
        sb.append("INGRESO TOTAL                    : $").append(String.format("%.2f", totalIngreso)).append("\n");
        return sb.toString();
    }
    
    // 7. Total recaudado por taxi
    // **************************************************************
    @WebMethod(operationName = "a7obtenerTotalRecaudadoTaxi")
    public String obtenerTotalRecaudadoTaxi(
            @WebParam(name = "placa") String placa) {

        Taxi taxi = null;
        for (Taxi t : taxis) {
            if (t.getPlaca().equalsIgnoreCase(placa)) { taxi = t; break; }
        }
        if (taxi == null)
            return "ERROR: No se encontró un taxi con placa: " + placa;

        Propietario prop     = taxi.getIdPropietario();
        double totalRecaudado = totalRecaudadoPorTaxi(taxi);
        double gananciaProp   = totalRecaudado * prop.getPorcentajePropietario() / 100.0;
        int    totalCarreras  = totalCarrerasPorTaxi(taxi);

        StringBuilder sb = new StringBuilder();
        sb.append("=== TOTAL RECAUDADO POR TAXI ===\n");
        sb.append("Taxi       : ").append(taxi.getPlaca())
          .append(" | ").append(taxi.getMarca()).append(" ").append(taxi.getModelo())
          .append(" (").append(taxi.getAnio()).append(")\n");
        sb.append("Propietario: ").append(prop.getNombres()).append(" ").append(prop.getApellidos()).append("\n\n");

        for (Chofer ch : taxi.getChoferes()) {
            double totalChofer = 0;
            int    carrerasCh  = 0;
            for (Jornada j : ch.getJornadas()) {
                if (j.getIdChofer().getIdTaxi().getIdTaxi() == taxi.getIdTaxi()) {
                    for (Carrera ca : j.getCarreras()) totalChofer += ca.getValorCarrera();
                    carrerasCh += j.getCarreras().size();
                }
            }
            double gananciaChofer = totalChofer * prop.getPorcentajeChofer() / 100.0;
            sb.append("  Chofer: ").append(ch.getNombres()).append(" ").append(ch.getApellidos()).append("\n");
            sb.append("    Carreras realizadas : ").append(carrerasCh).append("\n");
            sb.append("    Total generado      : $").append(String.format("%.2f", totalChofer)).append("\n");
            sb.append("    Ganancia chofer (").append(prop.getPorcentajeChofer()).append("%) : $")
              .append(String.format("%.2f", gananciaChofer)).append("\n\n");
        }

        sb.append("─────────────────────────────────\n");
        sb.append("Total carreras          : ").append(totalCarreras).append("\n");
        sb.append("TOTAL RECAUDADO         : $").append(String.format("%.2f", totalRecaudado)).append("\n");
        sb.append("Ganancia propietario (").append(prop.getPorcentajePropietario()).append("%) : $")
          .append(String.format("%.2f", gananciaProp)).append("\n");
        return sb.toString();
    }
}