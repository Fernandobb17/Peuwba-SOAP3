package test;

import sw.ConversionSW;
import sw.ConversionSW_Service;


public class Test {

    public static void main(String[] args) {

        // Crear conexión con el servicio SOAP
        ConversionSW_Service servicio = new ConversionSW_Service();
        ConversionSW ws = servicio.getConversionSWPort();

        System.out.println("====================================");
        System.out.println("1. GANANCIA DEL PROPIETARIO");
        System.out.println("====================================");

        String r1 = ws.a1ObtenerGananciaPropietario("0981503586");
        System.out.println(r1);


        System.out.println("\n====================================");
        System.out.println("2. GANANCIA DEL CHOFER");
        System.out.println("====================================");

        String r2 = ws.a2ObtenerGananciaChofer("1712345678");
        System.out.println(r2);


        System.out.println("\n====================================");
        System.out.println("3. TOTAL DE CARRERAS POR TAXI");
        System.out.println("====================================");

        String r3 = ws.a3ObtenerTotalCarrerasPorTaxi("G-1111");
        System.out.println(r3);


        System.out.println("\n====================================");
        System.out.println("4. TAXI MÁS RENTABLE");
        System.out.println("====================================");

        String r4 = ws.a4ObtenerTaxiMasRentable("0981503586");
        System.out.println(r4);


        System.out.println("\n====================================");
        System.out.println("5. MEJOR CHOFER");
        System.out.println("====================================");

        String r5 = ws.a5ObtenerMejorChofer("0981503586");
        System.out.println(r5);


        System.out.println("\n====================================");
        System.out.println("6. INGRESOS POR JORNADA");
        System.out.println("====================================");

        String r6 = ws.a6ObtenerIngresosPorJornada("G-1111", "Día");
        System.out.println(r6);


        System.out.println("\n====================================");
        System.out.println("7. TOTAL RECAUDADO POR TAXI");
        System.out.println("====================================");

        String r7 = ws.a7ObtenerTotalRecaudadoTaxi("G-1111");
        System.out.println(r7);

    }
}